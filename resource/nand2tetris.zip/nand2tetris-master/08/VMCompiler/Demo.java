package com.vmtranslator;

import java.io.IOException;

public class Demo {
	public static void main(String[] args) throws IOException {

	}
}
