package com.module;

public enum CommandType {
	A_COMMAND,C_COMMAND,L_COMMAND,UNKNOW
}
